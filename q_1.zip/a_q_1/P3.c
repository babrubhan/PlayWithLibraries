void P3()
{
	char c[]="Bye";
}

void P1()
{
	char c[] =  "Hello";
}


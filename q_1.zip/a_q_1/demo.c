#include<ppp.h>
#include<stdio.h>

int main()
{
	P1();
	P2();
	P3();
	return 0;	
}

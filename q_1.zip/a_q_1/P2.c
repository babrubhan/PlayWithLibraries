void P2()
{
	char c[]="Hai";
}
